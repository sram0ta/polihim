<?php

/**
 *
 * @package templates/default
 */

defined('ABSPATH') || defined('DUPXABSPATH') || exit;

/* Variables */
/* @var $bodyId string */
/* @var $bodyClasses string */
?>
<body id="<?php echo $bodyId; ?>" class="<?php echo $bodyClasses; ?>" >
